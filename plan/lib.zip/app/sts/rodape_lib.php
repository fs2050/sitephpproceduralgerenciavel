<script src="<?php echo pg; ?>/assets/js/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="<?php echo pg; ?>/assets/js/bootstrap.min.js"></script>
<script src="<?php echo pg; ?>/assets/js/scrollreveal.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/owl.carousel.js"></script>