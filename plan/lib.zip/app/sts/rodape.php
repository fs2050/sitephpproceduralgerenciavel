<footer class="footer bg-dark">
    <div class="container text-center">
     
        <a class="text-muted" href="HTTPS://WWW.PLANBWEBAPPS.COM.BR">@copyright Planbwebapps 2020<br> Whatsapp 9 5555-4621</a>
    </div>
</footer>
<footer class="container py-5">
      <div class="row">
        <div class="col-12 col-md">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="d-block mb-2"><circle cx="12" cy="12" r="10"></circle><line x1="14.31" y1="8" x2="20.05" y2="17.94"></line><line x1="9.69" y1="8" x2="21.17" y2="8"></line><line x1="7.38" y1="12" x2="13.12" y2="2.06"></line><line x1="9.69" y1="16" x2="3.95" y2="6.06"></line><line x1="14.31" y1="16" x2="2.83" y2="16"></line><line x1="16.62" y1="12" x2="10.88" y2="21.94"></line></svg>
          <small class="d-block mb-3 text-muted">PlanB 2020</small>
        </div>
        <div class="col-6 col-md">
          <h5>CLUBES DA CIDADE</h5>
          <ul class="list-unstyled text-small">
            <li><a class="text-muted" href="#">SE PEDREIRA</a></li>
            <li><a class="text-muted" href="#">AC BOEMIA</a></li>
            <li><a class="text-muted" href="#">MARAVILHA NEGRA</a></li>
            <li><a class="text-muted" href="#">REAL FAVELA FC</a></li>
             <li><a class="text-muted" href="#">FÚRIA OESTE FC</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>ORGÃOS</h5>
          <ul class="list-unstyled text-small">
            <li><a class="text-muted" href="http://www.carapicuiba.sp.gov.br/">Prefeitura Municipal de Carapicuiba</a></li>
            <li><a class="text-muted" href="https://www.gov.br/cidadania/pt-br/noticias-e-conteudos/esporte">Ministério do Esporte</a></li>
            <li><a class="text-muted" href="http://www.carapicuiba.sp.gov.br/index.php/esportelazer">Secretaria de Esporte, e Lazer e Juventude</a></li>
            <li><a class="text-muted" href="https://www.cbf.com.br/">CBF</a></li>
              <li><a class="text-muted" href="https://pt.fifa.com/u17worldcup/">FIFA</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>REDES SOCIAIS</h5>
          <ul class="list-unstyled text-small">
            <li><a class="text-muted" href="https://www.facebook.com/lifuca">FACEBOOK</a></li>
            <li><a class="text-muted" href="https://twitter.com/ligalifuca">TWITTER</a></li>
            <li><a class="text-muted" href="#">INSTAGRAM</a></li>
            <li><a class="text-muted" href="https://www.youtube.com/user/Waldemargallo">YOUTUBE</a></li>
              <li><a class="text-muted" href="https://web.whatsapp.com/">WHATSAPP</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>PARCEIROS</h5>
          <ul class="list-unstyled text-small">
            <li><a class="text-muted" href="http://bidfoodbr.com.br/">Bidfood Brasil</a></li>
                      <li><a class="text-muted" href="https://www.saopaulo.sp.gov.br/">Governo do Estado de São Paulo</a></li>
                                 <li><a class="text-muted" href="http://www.esportes.sp.gov.br/lei-paulista-de-incentivo-ao-esporte/">Lei de Incentivo ao Esporte</a></li>
                                  <li><a class="text-muted" href="https://www.atacadao.com.br/">Atacadão</a></li>
                                            <li><a class="text-muted" href="HTTPS://WWW.PLANBWEBAPPS.COM.BR">Planbwebapps</a></li>
          </ul>
        </div>
      </div>
    </footer>